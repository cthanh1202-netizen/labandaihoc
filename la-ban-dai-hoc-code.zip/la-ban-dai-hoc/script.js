"use strict";
const $ = (id) => document.getElementById(id);
const state = { method: "thpt", records: [], schools: [] };
const quotes = [
  "“The secret of getting ahead is getting started.”",
  "“Hành trình nghìn dặm bắt đầu từ một bước chân.”",
  "“It always seems impossible until it's done.”",
  "“Không cần đi nhanh nhất, hãy tiếp tục tiến về phía trước.”",
  "“Great things are done by a series of small things brought together.”"
];
const careerMap = {
  data: ["Công nghệ thông tin", "Khoa học dữ liệu", "Trí tuệ nhân tạo", "Hệ thống thông tin", "Công nghệ tài chính (FinTech)"],
  business: ["Quản trị kinh doanh", "Kinh doanh quốc tế", "Thương mại điện tử", "Logistics và quản lý chuỗi cung ứng", "Marketing"],
  finance: ["Tài chính – Ngân hàng", "Kế toán", "Kiểm toán", "Công nghệ tài chính (FinTech)", "Phân tích đầu tư"],
  people: ["Ngôn ngữ Anh", "Quan hệ quốc tế", "Truyền thông", "Quản trị nhân lực", "Tâm lý học"],
  design: ["Thiết kế đồ họa", "Truyền thông đa phương tiện", "Thiết kế nội thất", "Marketing sáng tạo", "Sản xuất nội dung số"]
};
let toastTimer;
function toast(message) {
  const el = $("toast");
  if (!el) return;
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2800);
}
function updateClock() {
  const now = new Date();
  $("liveClock").textContent = now.toLocaleString("vi-VN", {
    weekday: "short", day: "2-digit", month: "2-digit", year: "numeric",
    hour: "2-digit", minute: "2-digit", second: "2-digit"
  });
}
function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  })[ch]);
}
function normalize(value) {
  return String(value ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d").replace(/Đ/g, "D").toLowerCase().trim();
}
function getSchoolName(record) { return record.schoolName || record.school || ""; }
function getMajorName(record) { return record.majorName || record.major || ""; }
function getMethod(record) { return record.method || record.admissionMethod || ""; }
function getScore(record) {
  const score = Number(record.score ?? record.cutoffScore);
  return Number.isFinite(score) ? score : null;
}
function unique(values) { return [...new Set(values.filter(Boolean))].sort((a,b) => String(a).localeCompare(String(b), "vi")); }

async function loadCutoffData() {
  // Đặt dữ liệu đã kiểm chứng vào data/diem-chuan.json. Nếu chạy file trực tiếp,
  // hãy mở website bằng GitHub Pages hoặc máy chủ tĩnh để fetch() hoạt động.
  try {
    const response = await fetch("data/diem-chuan.json", { cache: "no-store" });
    if (!response.ok) throw new Error("Không tìm thấy tệp dữ liệu");
    const json = await response.json();
    state.records = Array.isArray(json) ? json : (Array.isArray(json.records) ? json.records : []);
    state.records = state.records.filter(r =>
      getSchoolName(r) && getMajorName(r) && getMethod(r) &&
      getScore(r) !== null && r.sourceUrl && /^https?:\/\//i.test(r.sourceUrl)
    );
    state.schools = unique(state.records.map(getSchoolName));
    renderMethodOptions();
    renderCutoffs();
  } catch (error) {
    state.records = [];
    state.schools = [];
    renderMethodOptions();
    renderCutoffs();
    console.info("Chưa nạp được data/diem-chuan.json:", error.message);
  }
}
function renderMethodOptions() {
  const select = $("methodFilter");
  const selected = select.value || "all";
  const methods = unique(state.records.map(getMethod));
  select.innerHTML = '<option value="all">Tất cả phương thức</option>' +
    methods.map(m => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join("");
  if ([...select.options].some(o => o.value === selected)) select.value = selected;
}
function getFilteredRecords() {
  const query = normalize($("schoolSearch").value);
  const year = $("yearFilter").value;
  const method = $("methodFilter").value;
  const combo = normalize($("comboFilter").value);
  const min = $("minScore").value === "" ? null : Number($("minScore").value);
  return state.records.filter(r => {
    const searchable = normalize([
      getSchoolName(r), getMajorName(r), r.majorCode, r.schoolCode,
      r.combinations, r.combo, getMethod(r), r.year
    ].join(" "));
    const score = getScore(r);
    return (!query || searchable.includes(query)) &&
      (year === "all" || String(r.year) === year) &&
      (method === "all" || getMethod(r) === method) &&
      (!combo || normalize(r.combinations || r.combo || "").includes(combo)) &&
      (min === null || (score !== null && score >= min));
  });
}
function renderCutoffs() {
  const results = getFilteredRecords();
  $("resultCount").textContent = `${results.length} kết quả`;
  const root = $("cutoffResults");
  if (!results.length) {
    root.innerHTML = `<div class="empty-state"><div class="empty-symbol">⌕</div><h3>${state.records.length ? "Không tìm thấy kết quả phù hợp" : "Chưa có dữ liệu điểm chuẩn được nạp"}</h3><p>${state.records.length ? "Thử đổi từ khóa hoặc bỏ bớt bộ lọc." : 'Hãy thêm dữ liệu có nguồn chính thức vào <code>data/diem-chuan.json</code>. Không hiển thị điểm minh họa như dữ liệu thật.'}</p><p class="small-muted">Dữ liệu được lọc bỏ nếu thiếu đường dẫn nguồn hợp lệ.</p></div>`;
    return;
  }
  const grouped = new Map();
  for (const r of results) {
    const name = getSchoolName(r);
    if (!grouped.has(name)) grouped.set(name, []);
    grouped.get(name).push(r);
  }
  root.innerHTML = [...grouped.entries()].map(([school, rows]) => {
    const first = rows[0];
    const logo = first.logoUrl && /^https?:\/\//i.test(first.logoUrl)
      ? `<img class="school-logo" src="${escapeHtml(first.logoUrl)}" alt="Logo ${escapeHtml(school)}" loading="lazy" onerror="this.outerHTML='<span class=&quot;school-logo&quot;>${escapeHtml((first.schoolShort || school.slice(0,3)).toUpperCase())}</span>'">`
      : `<span class="school-logo">${escapeHtml((first.schoolShort || school.slice(0,3)).toUpperCase())}</span>`;
    return `<article class="cutoff-card"><div class="cutoff-card-head">${logo}<div><div class="school-name">${escapeHtml(school)}</div><div class="school-meta">${rows.length} bản ghi · Năm ${escapeHtml(unique(rows.map(r=>r.year)).join(", "))}</div></div></div><div class="cutoff-table-wrap"><table class="cutoff-table"><thead><tr><th>Mã ngành</th><th>Tên ngành</th><th>Tổ hợp</th><th>Phương thức</th><th>Năm</th><th>Điểm chuẩn</th><th>Nguồn</th></tr></thead><tbody>${rows.map(r => `<tr><td>${escapeHtml(r.majorCode || "—")}</td><td><b>${escapeHtml(getMajorName(r))}</b></td><td>${escapeHtml(r.combinations || r.combo || "—")}</td><td>${escapeHtml(getMethod(r))}</td><td>${escapeHtml(r.year)}</td><td><span class="cutoff-score">${Number(getScore(r)).toLocaleString("vi-VN",{maximumFractionDigits:2})}</span></td><td><a class="source-link" href="${escapeHtml(r.sourceUrl)}" target="_blank" rel="noopener noreferrer">Xem nguồn ↗</a></td></tr>`).join("")}</tbody></table></div></article>`;
  }).join("");
}
function showSuggestions() {
  const query = normalize($("schoolSearch").value);
  const box = $("suggestions");
  if (!query || !state.records.length) { box.hidden = true; box.innerHTML = ""; return; }
  const matches = unique(state.records.filter(r =>
    normalize([getSchoolName(r), getMajorName(r), r.majorCode].join(" ")).includes(query)
  ).map(getSchoolName)).slice(0, 7);
  if (!matches.length) { box.hidden = true; return; }
  box.innerHTML = matches.map(name => `<button type="button" class="suggestion-item" data-school="${escapeHtml(name)}"><span class="suggestion-logo">${escapeHtml(name.slice(0,3).toUpperCase())}</span><span><b>${escapeHtml(name)}</b><small>Nhấn để tìm điểm chuẩn</small></span></button>`).join("");
  box.hidden = false;
  box.querySelectorAll("[data-school]").forEach(btn => btn.addEventListener("click", () => {
    $("schoolSearch").value = btn.dataset.school;
    box.hidden = true;
    renderCutoffs();
  }));
}
function calculateScore() {
  const ids = ["score1","score2","score3"];
  const vals = ids.map(id => $(id).value.trim() === "" ? null : Number($(id).value));
  if (vals.some(v => v === null || !Number.isFinite(v) || v < 0 || v > 10)) {
    $("totalScore").innerHTML = "—<small>/ 30</small>";
    $("rawScore").textContent = "—";
    $("bonusDisplay").textContent = "—";
    $("calcMessage").textContent = "Hãy nhập đủ 3 môn, mỗi môn từ 0 đến 10.";
    return;
  }
  const extra = Number($("extraScore").value || 0);
  const other = Number($("otherBonus").value || 0);
  const region = Number($("region").value || 0);
  if ([extra,other,region].some(v => !Number.isFinite(v) || v < 0)) {
    toast("Kiểm tra lại điểm cộng và điểm ưu tiên.");
    return;
  }
  const raw = vals.reduce((a,b)=>a+b,0);
  const bonus = extra + other + region;
  const total = Math.min(30, raw + bonus);
  $("totalScore").innerHTML = `${total.toLocaleString("vi-VN",{maximumFractionDigits:2})}<small>/ 30</small>`;
  $("rawScore").textContent = raw.toLocaleString("vi-VN",{maximumFractionDigits:2});
  $("bonusDisplay").textContent = bonus.toLocaleString("vi-VN",{maximumFractionDigits:2});
  $("calcMessage").textContent = total >= 25 ? "Điểm tham khảo khá cao — hãy đối chiếu điểm chuẩn từng ngành và phương thức." : "Hãy đối chiếu điểm chuẩn các năm trước và điều kiện của từng trường.";
}
function updateCountdown() {
  // Mốc dự kiến 27/06/2027, không phải lịch thi chính thức.
  const target = new Date("2027-06-27T07:30:00+07:00").getTime();
  const diff = Math.max(0, target - Date.now());
  const day = Math.floor(diff / 86400000);
  const hour = Math.floor((diff % 86400000) / 3600000);
  const minute = Math.floor((diff % 3600000) / 60000);
  const second = Math.floor((diff % 60000) / 1000);
  $("days").textContent = String(day).padStart(3,"0");
  $("hours").textContent = String(hour).padStart(2,"0");
  $("minutes").textContent = String(minute).padStart(2,"0");
  $("seconds").textContent = String(second).padStart(2,"0");
}
function setupEvents() {
  ["schoolSearch","yearFilter","methodFilter","comboFilter","minScore"].forEach(id => {
    $(id).addEventListener("input", () => { renderCutoffs(); if(id==="schoolSearch") showSuggestions(); });
    $(id).addEventListener("change", renderCutoffs);
  });
  $("clearSearch").addEventListener("click", () => {
    $("schoolSearch").value = ""; $("suggestions").hidden = true; renderCutoffs();
  });
  $("resetFilters").addEventListener("click", () => {
    $("schoolSearch").value = ""; $("yearFilter").value = "all"; $("methodFilter").value = "all";
    $("comboFilter").value = ""; $("minScore").value = ""; $("suggestions").hidden = true;
    renderCutoffs(); toast("Đã đặt lại bộ lọc.");
  });
  document.addEventListener("click", e => {
    if (!e.target.closest(".search-main")) $("suggestions").hidden = true;
  });
  $("calculateBtn").addEventListener("click", calculateScore);
  document.querySelectorAll(".calc-tab").forEach(btn => btn.addEventListener("click", () => {
    document.querySelectorAll(".calc-tab").forEach(b => b.classList.toggle("active", b === btn));
    state.method = btn.dataset.tab;
    toast(state.method === "hocba" ? "Chế độ học bạ: nhập điểm trung bình/điểm quy đổi theo cách tính của trường." : "Chế độ điểm thi THPT.");
    document.querySelectorAll(".subject-score").forEach((input,i) => {
      input.value = "";
      input.previousElementSibling && (input.previousElementSibling.textContent = ["Môn 1","Môn 2","Môn 3"][i]);
      input.placeholder = state.method === "hocba" ? "Điểm học bạ" : "0–10";
    });
    calculateScore();
  }));
  $("careerBtn").addEventListener("click", () => {
    const items = careerMap[$("interestSelect").value] || [];
    $("careerResult").innerHTML = `<strong>Nhóm ngành bạn có thể tìm hiểu:</strong><br>${items.map(escapeHtml).join(" · ")}<br><span class="small-muted">Hãy xem chương trình đào tạo, môn học, cơ hội nghề nghiệp và điều kiện tuyển sinh của từng trường.</span>`;
  });
  $("newQuote").addEventListener("click", () => {
    const current = $("quoteText").textContent;
    const choices = quotes.filter(q => q !== current);
    $("quoteText").textContent = choices[Math.floor(Math.random()*choices.length)];
  });
  $("themeToggle").addEventListener("click", () => {
    document.body.classList.toggle("dark");
    $("themeToggle").textContent = document.body.classList.contains("dark") ? "☀" : "☾";
  });
  $("menuToggle").addEventListener("click", () => $("mainNav").classList.toggle("open"));
  document.querySelectorAll("#mainNav a").forEach(a => a.addEventListener("click", () => $("mainNav").classList.remove("open")));
}
updateClock();
setInterval(updateClock, 1000);
updateCountdown();
setInterval(updateCountdown, 1000);
setupEvents();
loadCutoffData();
