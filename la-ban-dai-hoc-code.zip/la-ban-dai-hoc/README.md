# La Bàn Đại Học — website tra cứu điểm chuẩn

## Chạy trên GitHub Pages
1. Giải nén thư mục.
2. Đưa `index.html`, `style.css`, `script.js` và thư mục `data/` vào thư mục gốc repo GitHub Pages.
3. Bật GitHub Pages trong **Settings → Pages** (Deploy from branch, branch `main`, folder `/root`).
4. Mở website bằng URL HTTPS của GitHub Pages hoặc tên miền đã cấu hình.

## Nạp dữ liệu điểm chuẩn
Sửa `data/diem-chuan.json`. Tệp mặc định để trống có chủ đích, vì không được tự bịa điểm chuẩn.

Ví dụ cấu trúc cho **một bản ghi đã kiểm chứng** (thay toàn bộ giá trị bằng dữ liệu thật và nguồn chính thức trước khi dùng):
```json
{
  "records": [
    {
      "year": 2025,
      "schoolName": "Tên trường theo nguồn chính thức",
      "schoolShort": "ABC",
      "schoolCode": "Mã trường nếu có",
      "logoUrl": "https://duong-dan-logo-hop-le.example/logo.png",
      "majorCode": "Mã ngành",
      "majorName": "Tên ngành",
      "combinations": "A00; A01",
      "method": "Điểm thi tốt nghiệp THPT",
      "score": 25.5,
      "sourceUrl": "https://website-chinh-thuc-cua-truong.example/thong-bao"
    }
  ]
}
```

Các trường bắt buộc để website hiển thị bản ghi: `year`, `schoolName`/`school`, `majorName`/`major`, `method`/`admissionMethod`, `score`/`cutoffScore`, `sourceUrl` là URL HTTP(S) hợp lệ. Nên thêm `majorCode`, `combinations`, `logoUrl` nếu có. Có thể dùng nhiều bản ghi cho cùng một ngành nếu năm/phương thức/tổ hợp khác nhau.

## Lưu ý
- Bộ code này cung cấp giao diện và chức năng lọc dữ liệu, **không tự động chứa toàn bộ điểm chuẩn Việt Nam**.
- Chỉ thêm dữ liệu sau khi đối chiếu thông báo chính thức của trường hoặc cơ quan tuyển sinh; giữ URL nguồn để người xem kiểm chứng.
- Mốc đếm ngược 27/06/2027 chỉ là mốc dự kiến trong giao diện, hãy sửa trong `script.js` khi có lịch thi chính thức.
- Công cụ tính điểm là tham khảo; công thức ưu tiên thực tế có thể thay đổi theo quy chế và trường.
